import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Github, Globe, Zap } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadReport = () => {
    setIsDownloading(true);
    // Simulate download
    setTimeout(() => setIsDownloading(false), 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Navigation */}
      <nav className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">T</span>
            </div>
            <span className="font-bold text-lg text-slate-900">TELsTP</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#research" className="text-sm text-slate-600 hover:text-slate-900 transition">Research</a>
            <a href="#findings" className="text-sm text-slate-600 hover:text-slate-900 transition">Findings</a>
            <a href="#download" className="text-sm text-slate-600 hover:text-slate-900 transition">Download</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-block mb-6 px-4 py-2 bg-blue-100 rounded-full">
            <span className="text-sm font-semibold text-blue-700">Global Benchmark Report 2025</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
            AI in Life Science Clusters: A Global Benchmark
          </h1>
          
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Comprehensive analysis of 30 global life science clusters and leading academic institutions, 
            exploring AI adoption, human-AI collaboration, and the strategic vision for the TELsTP initiative.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700 text-white"
              onClick={handleDownloadReport}
              disabled={isDownloading}
            >
              <Download className="w-4 h-4 mr-2" />
              {isDownloading ? "Downloading..." : "Download Full Report (PDF)"}
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-slate-300 text-slate-700 hover:bg-slate-50"
            >
              <Globe className="w-4 h-4 mr-2" />
              View on GitHub
            </Button>
          </div>
        </div>
      </section>

      {/* Key Metrics */}
      <section className="container py-16">
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="border-slate-200 bg-white/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-slate-600">Global Clusters</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-slate-900">30</p>
              <p className="text-xs text-slate-500 mt-2">Analyzed across 6 regions</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-slate-600">Top Institutions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-slate-900">20+</p>
              <p className="text-xs text-slate-500 mt-2">Leading universities studied</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-slate-600">Research Areas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-slate-900">5</p>
              <p className="text-xs text-slate-500 mt-2">Core research dimensions</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-slate-600">Target Outcome</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-slate-900">25K</p>
              <p className="text-xs text-slate-500 mt-2">Researchers by 2027</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Research Highlights */}
      <section id="research" className="container py-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-12 text-center">
            Research Highlights
          </h2>

          <div className="space-y-6">
            <Card className="border-slate-200 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Zap className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">Global AI Adoption Trends</CardTitle>
                    <CardDescription className="mt-2">
                      The global life science ecosystem is shifting from AI as a tool to AI as a collaborative agent. 
                      Leading institutions are actively defining the boundary between AI as a supportive assistant and AI as a collaborative partner.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <Card className="border-slate-200 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Globe className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">30 Clusters Mapped</CardTitle>
                    <CardDescription className="mt-2">
                      Comprehensive analysis of 20 MedCity anchor clusters (Boston, London, Singapore) and 10 emerging hubs 
                      (Riyadh, Dubai, Warsaw) positioned for AI-driven growth.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <Card className="border-slate-200 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🌍</span>
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">Arabic Language Challenge</CardTitle>
                    <CardDescription className="mt-2">
                      Identified critical linguistic and data challenges unique to Arabic for long-term AI study companions. 
                      Proposed solutions include dedicated localized model architecture and accreditation framework.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Key Findings */}
      <section id="findings" className="bg-gradient-to-r from-blue-600 to-indigo-600 py-20 text-white">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            Key Findings
          </h2>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="space-y-3">
              <h3 className="text-xl font-bold">Empowerment vs. Dependence</h3>
              <p className="text-blue-100">
                AI acts as a cognitive multiplier when paired with critical thinking education. 
                The key is AI literacy—teaching students to verify outputs against authentic sources.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-xl font-bold">Multi-Year Memory</h3>
              <p className="text-blue-100">
                TELsTP's vision of a 5+ year AI companion is technologically feasible through persistent 
                knowledge graphs and personalized fine-tuning architectures.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-xl font-bold">Academic Accreditation</h3>
              <p className="text-blue-100">
                Granting AI companions academic accreditation transforms them from tools into transparent, 
                accountable partners—a policy innovation that sets a new global standard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section id="download" className="container py-20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
            Access the Full Report
          </h2>
          
          <p className="text-lg text-slate-600 mb-8">
            Download the comprehensive TELsTP Global Benchmark Report including detailed analysis of all 30 clusters, 
            institutional practices, and strategic recommendations.
          </p>

          <Card className="border-slate-200 bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-3">
                <Download className="w-6 h-6 text-blue-600" />
                <span className="text-lg font-semibold text-slate-900">TELsTP_Global_Benchmark_Report.pdf</span>
              </div>
              <p className="text-sm text-slate-600">Comprehensive research document | 6 sections | Full citations</p>
              <Button 
                size="lg" 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                onClick={handleDownloadReport}
                disabled={isDownloading}
              >
                <Download className="w-4 h-4 mr-2" />
                {isDownloading ? "Downloading..." : "Download Report"}
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white/50 backdrop-blur-sm py-12">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div>
                <h4 className="font-bold text-slate-900 mb-4">About TELsTP</h4>
                <p className="text-sm text-slate-600">
                  TELsTP is Egypt's first hybrid Life Science Technology Park, dedicated to graduating 25,000 highly qualified researchers.
                </p>
              </div>
              <div>
                <h4 className="font-bold text-slate-900 mb-4">Research Scope</h4>
                <ul className="text-sm text-slate-600 space-y-2">
                  <li>30 Global Clusters</li>
                  <li>20+ Leading Universities</li>
                  <li>AI Integration Analysis</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-slate-900 mb-4">Resources</h4>
                <ul className="text-sm text-slate-600 space-y-2">
                  <li><a href="#" className="hover:text-slate-900 transition">GitHub Repository</a></li>
                  <li><a href="#" className="hover:text-slate-900 transition">Full Report PDF</a></li>
                  <li><a href="#" className="hover:text-slate-900 transition">Contact</a></li>
                </ul>
              </div>
            </div>

            <div className="border-t border-slate-200 pt-8 text-center text-sm text-slate-600">
              <p>© 2025 TELsTP Global Benchmark Report. Prepared by Manus AI.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
